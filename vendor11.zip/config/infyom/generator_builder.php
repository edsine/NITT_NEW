<?php

return [

    'views' => [

        'builder' => 'infyom.generator-builder.builder',

        'field-template' => 'infyom.generator-builder.field-template',

        'relation-field-template' => 'generator-builder::relation-field-template',
    ],
];
