require('./bootstrap');


import './bootstrap';
import 'laravel-datatables-vite';