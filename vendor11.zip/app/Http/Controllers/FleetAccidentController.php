<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\FleetAccident;

class FleetAccidentController extends Controller
{
    //
}
