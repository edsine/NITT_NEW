<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\FleetOperatorBrand;
class FleetOperatorBrandController extends Controller
{
    //
}
