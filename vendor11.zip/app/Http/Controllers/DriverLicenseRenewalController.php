<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\DriverLicenseRenewal;

class DriverLicenseRenewalController extends Controller
{
    //
}
