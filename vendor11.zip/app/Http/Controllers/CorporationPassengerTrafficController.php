<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\CorporationPassengerTraffic;

class CorporationPassengerTrafficController extends Controller
{
    //
}
