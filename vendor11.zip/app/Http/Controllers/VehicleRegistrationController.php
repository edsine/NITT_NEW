<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\VehicleRegistration;

class VehicleRegistrationController extends Controller
{
    //
}
