<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\DrivingTestRecord;

class DrivingTestRecordController extends Controller
{
    //
}
