<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\RoadTrafficCrash;

class RoadTrafficCrashController extends Controller
{
    //
}
