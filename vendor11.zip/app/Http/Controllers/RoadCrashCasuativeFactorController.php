<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\RoadCrashCausativeFactor;

class RoadCrashCasuativeFactorController extends Controller
{
    //
}
