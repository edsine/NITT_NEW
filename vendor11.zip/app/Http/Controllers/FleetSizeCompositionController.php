<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\FleetSizeComposition;

class FleetSizeCompositionController extends Controller
{
    //
}
